
import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import multer from 'multer';
import cors from 'cors';
import { shopifyApi, LATEST_API_VERSION } from '@shopify/shopify-api';

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGODB_URI);

const Review = mongoose.model('Review', new mongoose.Schema({
  shop: String,
  productId: String,
  name: String,
  rating: Number,
  text: String,
  images: [String],
  status: { type: String, default: 'pending' },
  createdAt: { type: Date, default: Date.now }
}));

const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY,
  apiSecretKey: process.env.SHOPIFY_API_SECRET,
  scopes: process.env.SCOPES.split(","),
  hostName: process.env.HOST.replace("https://", ""),
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true
});

const upload = multer({ dest: 'uploads/' });

app.post('/reviews', upload.array('images', 2), async (req, res) => {
  const review = new Review({
    shop: req.body.shop,
    productId: req.body.productId,
    name: req.body.name,
    rating: req.body.rating,
    text: req.body.text,
    images: req.files.map(f => f.filename)
  });
  await review.save();
  res.json({ success: true });
});

app.get('/reviews/:productId', async (req, res) => {
  const reviews = await Review.find({ 
    productId: req.params.productId, 
    status: 'approved' 
  });
  res.json(reviews);
});

app.post('/reviews/:id/approve', async (req, res) => {
  await Review.findByIdAndUpdate(req.params.id, { status: 'approved' });
  res.json({ success: true });
});

app.post('/reviews/:id/reject', async (req, res) => {
  await Review.findByIdAndUpdate(req.params.id, { status: 'rejected' });
  res.json({ success: true });
});

app.listen(3000, () => console.log('Server running on port 3000'));
